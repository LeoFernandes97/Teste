package br.com.fiap.jdbc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.jdbc.dao.CategoriaDAO;
import br.com.fiap.jdbc.model.Categoria;
import br.com.fiap.jdbc.model.Produto;

/**
 * Servlet implementation class listaProdutoCategoria
 */
@WebServlet("/listaProdutosCategoria")
public class listaProdutoCategoria extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoriaDAO catDAO = new CategoriaDAO();
	/**
     * @see HttpServlet#HttpServlet()
     */
    public listaProdutoCategoria() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Categoria> cats = (ArrayList<Categoria>) catDAO.listarComProduto();


		request.setAttribute("categorias", cats);
		RequestDispatcher rd = request.getRequestDispatcher("/listaProdutosCategoria.jsp");
		rd.forward(request, response);
	}
}
